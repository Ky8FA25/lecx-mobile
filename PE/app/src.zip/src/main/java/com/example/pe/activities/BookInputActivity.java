package com.example.pe.activities;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.pe.R;
import com.example.pe.data.UserDAO;
import com.example.pe.models.User;

public class BookInputActivity extends AppCompatActivity {

}
