//package com.example.pe.data;
//
//import android.content.ContentValues;
//import android.content.Context;
//import android.database.Cursor;
//import android.database.sqlite.SQLiteDatabase;
//
//import com.example.pe.models.Book;
//
//import java.util.ArrayList;
//import java.util.List;
//
//public class BookDAO {
//    private SQLiteDatabase db;
//    private DatabaseHelper dbHelper;
//
//    public BookDAO(Context context) {
//        dbHelper = new DatabaseHelper(context);
//    }
//
//
//    public long insertProduct(Book book) {
//        ContentValues values = new ContentValues();
//        values.put(DatabaseHelper.COLUMN_PRODUCT_NAME, book.getName());
//        values.put(DatabaseHelper.COLUMN_PRODUCT_PRICE, book.getPrice());
//
//        return db.insert(DatabaseHelper.TABLE_BOOK, null, values);
//    }
//
//    // ===== 2. Lấy tất cả sản phẩm =====
//    public List<Book> getAllProducts() {
//        List<Book> bookList = new ArrayList<>();
//
//        Cursor cursor = db.query(DatabaseHelper.TABLE_PRODUCT,
//                null, // all columns
//                null, null, null, null, null);
//
//        if (cursor != null && cursor.moveToFirst()) {
//            do {
//                Product product = new Product();
//                product.setId(cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_PRODUCT_ID)));
//                product.setName(cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_PRODUCT_NAME)));
//                product.setPrice(cursor.getDouble(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_PRODUCT_PRICE)));
//                product.setDescription(cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_PRODUCT_DESC)));
//                product.setImage(cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_PRODUCT_IMAGE)));
//                product.setCategoryId(cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_PRODUCT_CATEGORY_ID)));
//
//                bookList.add(product);
//            } while (cursor.moveToNext());
//            cursor.close();
//        }
//
//        return bookList;
//    }
//}
