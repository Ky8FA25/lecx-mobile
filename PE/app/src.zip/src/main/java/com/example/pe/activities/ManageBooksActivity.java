package com.example.pe.activities;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.pe.R;
import com.example.pe.adapters.ProductAdapter;
//import com.example.pe.data.BookDAO;
import com.example.pe.data.CategoryDAO;
import com.example.pe.data.ProductDAO;
import com.example.pe.models.Category;
import com.example.pe.models.Product;

import java.util.ArrayList;
import java.util.List;
public class ManageBooksActivity extends AppCompatActivity {

    private RecyclerView rvProducts;
    private EditText searchProduct;
    private Button btnAdd;
    private ProductAdapter adapter;

    private List<Product> productList;
    private BookDAO bookDAO;

}
